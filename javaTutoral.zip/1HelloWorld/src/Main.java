public class Main {
    //the below will print my name
    public static void main(String[] args){//the below will print my name


        /*the below will print my name
         the below will print my name
         the below will print my name */
        System.out.println("Muhammed Essa");
        System.out.println("Ahmed Essa");
        System.out.println("Osama Essa");
    }
}
