package defaultPackage;

class Person {
}

