package defaultPackage;

public class Animal {
  protected void  showInfo( ){
    System.out.println("Muhammed");
  }
}

