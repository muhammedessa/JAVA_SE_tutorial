interface Person{
    void showInfo(String name,int age);
   static void showInfo4(String name,int age) {
       System.out.println("Name: "+name+" Age: "+ age);
   }
}

interface Employee{
    void showInfo2(String name,float salary);
}

interface People extends Employee,Person{
    void showInfo3(String name,float salary);
}

class  Muhammed implements Person,Employee{

    @Override
    public void showInfo(String name, int age) {
        System.out.println("Name: "+name+" Age: "+ age);
    }

    @Override
    public void showInfo2(String name, float salary) {
        System.out.println("Name: "+name+" salary: "+ salary);
    }
}

public class Main {
    public static void main(String[] args) {
        Muhammed m1 = new Muhammed();
        m1.showInfo("Muhammed",40);
        m1.showInfo2("Muhammed",4000.3f);
    }
}