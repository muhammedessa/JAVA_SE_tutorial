 
public class Main {
    public static void main(String[] args) {

        Muhammed m1 = new Muhammed();
        m1.name ="Muhammed2";
        m1.age = 40;
        m1.salary = 3000.0f;
        m1.showInfo();
        m1.showMuhammed();

        Ahmed a1 = new Ahmed();
        a1.name ="Ahmed";
        a1.age = 34;
        a1.salary = 2000.0f;
        a1.showInfo();
        a1.showAhmed();
    }
}