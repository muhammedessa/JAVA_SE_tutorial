class Ahmed extends Employee{
    public void showAhmed(){
        System.out.println("Class muhammed");
    }
}