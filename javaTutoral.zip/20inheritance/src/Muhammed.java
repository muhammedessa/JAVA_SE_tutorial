class Muhammed extends Employee{
    public void showMuhammed(){
        System.out.println("Class muhammed");
    }
}