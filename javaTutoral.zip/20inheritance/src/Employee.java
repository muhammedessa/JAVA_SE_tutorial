class Employee{
    String name;
    int age;
    float salary;
    public void showInfo(){
        System.out.println("My name is: " +name +" and my age is : "+ age + " my salary = " + salary);
    }
}
