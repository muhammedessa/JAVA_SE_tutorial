package com.muhammedessa.databaseclasses;

public class Employee {
}
