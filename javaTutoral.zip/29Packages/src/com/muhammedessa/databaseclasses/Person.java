package com.muhammedessa.databaseclasses;

public class Person {
}
