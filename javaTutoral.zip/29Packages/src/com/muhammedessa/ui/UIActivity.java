package com.muhammedessa.ui;

public class UIActivity {
}
