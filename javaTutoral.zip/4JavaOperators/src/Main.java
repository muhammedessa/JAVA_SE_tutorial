
public class Main {
    public static void main(String[] args) {

        //Java Arithmetic Operators
        int a = 30,  b = 11;
        int sum = a+ b;
//        System.out.println(sum);
//        System.out.println(a- b);
//        System.out.println(a * b);
//        System.out.println( "divide: " +  (a / b));
//        System.out.println("a % b : " +  (a % b));

        //Java Assignment Operators
        double salary = 1000;
        float salary2 ;
        salary2 = 5000;
        float var;
        var = salary2;
//        System.out.println("var= : " +  var);
//        var += salary2; // var = var + salary2
//        System.out.println("var= : " +  var);
//        var -= salary2; // var = var - salary2
//        System.out.println("var= : " +  var);
//        var *= salary2; // var = var * salary2
//        System.out.println("var= : " +  var);

        // Relational Operators
        int num1 = 10 , num2 = 2;
//        System.out.println(num1 == num2 );
//        System.out.println(num1 != num2 );
//        System.out.println(num1 > num2 );
//        System.out.println(num1 < num2 );
//        System.out.println(num1 >= num2 );
//        System.out.println(num1 <= num2 );


        //Logical Operators
//        System.out.println((7>3)  && (8>2) );
//        System.out.println((7<3)  && (8>2) );
//
//        System.out.println((7>3)  || (8>2) );
//        System.out.println((7<3)  || (8>2) );

        //Java Unary Operators
        int num4 = 4;

//        System.out.println(num4  );
//        System.out.println( ++num4  );
//        System.out.println( --num4  );

        // Java instanceof Operator
        String name = "Muhammed Essa";
      //  boolean result ;
//        result = name instanceof String;
//        System.out.println( result  );

        //Java Ternary Operator
        int age = 13;
        String result;
        result = (age == 18 ) ?  "Welcome": "No you can not!";
        System.out.println( result  );
    }
}