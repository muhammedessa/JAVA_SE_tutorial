public class Person {

    protected void showInfo(){
        System.out.println("class Person");
    }


}
