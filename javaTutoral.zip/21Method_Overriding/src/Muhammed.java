public class Muhammed extends Person{

    @Override
    public void showInfo(){
        System.out.println("class Muhammed");
    }

}
