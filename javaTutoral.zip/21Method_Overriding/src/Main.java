
public class Main {
    public static void main(String[] args) {

        Person p1 = new Person();
        p1.showInfo();
        Muhammed m1 = new Muhammed();
        m1.showInfo();
    }
}