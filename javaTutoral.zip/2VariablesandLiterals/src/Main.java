
public class Main {
    public static void main(String[] args) {

//        int age = 30;
//        int salary;
//        salary=3000;
//        age = 44;
//
//        float salary;

//        int age = 24;
//        int AGE = 25;
//   System.out.println(age);
//        System.out.println(AGE);


//        int age_2 = 25;

       int age =10;
       float myOwnSalary = 4000.9F;

        System.out.println(myOwnSalary);

        int num1 = 2;
        float num2 = 4.6F;
        double num7 = 4.6;
        char car1 = 'D';
        int num3 = 44;
        int num4 = 0x2F;
        int num5 = 0b10010;
        int num6 = 027;
        String name = "Muhammed Essa";
        boolean status1 = false;
        boolean status2 = true;

    }
}