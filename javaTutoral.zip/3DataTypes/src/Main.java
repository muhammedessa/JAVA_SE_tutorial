// Primitive Data types
public class Main {
    public static void main(String[] args) {

        //boolean type
//        boolean status = true;
//        boolean status2 = false;

        //byte type -128 to 127
//        byte num = 123;

        //short type -32768 to 32767
//        short num = -200;

        //int type -2^31 to 2^31-1 unsigned integer 32bit 0 to 2^32-1
//        int age = 40;

        //long type -2^63 to 2^63-1
//        long num2 = 32446600000L;

        //double type 64bit
        double num3 = 33.6;
        //float type 32bit
        float num4 = 22.4f;
        //char type
        char letter = 65;
        //String type
        String name = "Muhammed Essa Hameed";
        System.out.println(name);
    }
}